{
    "sEmptyTable":     "No hay información disponible en la tabla",
    "sInfo":           "Mostrando _START_ a _END_ de _TOTAL_ entradas",
    "sInfoEmpty":      "Mostrando 0 a 0 de 0 entradas",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ entradas)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "Mostrar entradas de _MENU_",
    "sLoadingRecords": "Cargando...",
    "sProcessing":     "Procesando...",
    "sSearch":         "Buscar:",
    "sZeroRecords":    "No se encontraron resultados compatibles",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Ultimo",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": activar para ordenar columnas en orden ascendente",
        "sSortDescending": ": activar para ordenar columnas en orden ascendente descendente"
    }
}